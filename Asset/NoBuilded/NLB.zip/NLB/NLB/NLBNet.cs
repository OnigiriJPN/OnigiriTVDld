﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace NLB
{
    public class NLBNet
    {
        [DllImport("Wlanapi.dll")]
        private static extern int WlanOpenHandle(
            uint dwClientVersion,
            IntPtr pReserved,
            out uint pdwNegotiatedVersion,
            out IntPtr phClientHandle);

        [DllImport("Wlanapi.dll")]
        private static extern int WlanCloseHandle(
            IntPtr hClientHandle,
            IntPtr pReserved);

        [DllImport("Wlanapi.dll")]
        private static extern int WlanEnumInterfaces(
            IntPtr hClientHandle,
            IntPtr pReserved,
            out IntPtr ppInterfaceList);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct WLAN_INTERFACE_INFO
        {
            public Guid InterfaceGuid;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string strInterfaceDescription;
            public int isState;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct WLAN_INTERFACE_INFO_LIST
        {
            public int dwNumberOfItems;
            public int dwIndex;
            public WLAN_INTERFACE_INFO[] InterfaceInfo;

            public WLAN_INTERFACE_INFO_LIST(IntPtr ppList)
            {
                dwNumberOfItems = Marshal.ReadInt32(ppList, 0);
                dwIndex = Marshal.ReadInt32(ppList, 4);
                InterfaceInfo = new WLAN_INTERFACE_INFO[dwNumberOfItems];

                for (int i = 0; i < dwNumberOfItems; i++)
                {
                    IntPtr pItemList = new IntPtr(ppList.ToInt64() + 8 + i * Marshal.SizeOf(typeof(WLAN_INTERFACE_INFO)));
                    InterfaceInfo[i] = (WLAN_INTERFACE_INFO)Marshal.PtrToStructure(pItemList, typeof(WLAN_INTERFACE_INFO));
                }
            }
        }

        public static string GetConnectedSSID()
        {
            IntPtr clientHandle = IntPtr.Zero;
            uint negotiatedVersion = 0;

            int ret = WlanOpenHandle(2, IntPtr.Zero, out negotiatedVersion, out clientHandle);
            if (ret != 0) return "不明なネットワーク名";

            IntPtr ppInterfaceList = IntPtr.Zero;
            ret = WlanEnumInterfaces(clientHandle, IntPtr.Zero, out ppInterfaceList);
            if (ret != 0) return "不明なネットワーク名";

            var list = new WLAN_INTERFACE_INFO_LIST(ppInterfaceList);
            string ssid = list.InterfaceInfo.Length > 0 ? list.InterfaceInfo[0].strInterfaceDescription : "Unknown";

            WlanCloseHandle(clientHandle, IntPtr.Zero);
            return ssid;
        }
    }
}
